#!/usr/bin/python
# -*- coding: UTF-8 -*-
#微信公众号 AI壹号堂 欢迎关注
#Author 杨博
import tensorflow as tf
from tensorflow.keras.layers import Dense, LSTM, Input

class Config(object):

    """配置参数"""
    def __init__(self, dataset):
        self.model_name = 'Seq2Seq'
        self.train_path = dataset + '/data/train.txt'                                # 训练数据集
        self.test_path = dataset + '/data/test.txt'                                  # 测试数据集
        self.save_path = dataset + '/saved_dict/' + self.model_name + '.h5'        # 模型训练结果
        self.num_samples = 10000                                                     # 最多10000个样本参与训练 为了内存考虑

        self.num_epochs = 200                                           # epoch数
        self.batch_size = 64                                           # mini-batch大小
        self.learning_rate = 1e-3                                       # 学习率
        self.hidden_size = 256                                          # 卷积核数量(channels数)
        self.num_encoder_tokens = 0                                     # encoder中token数量，在运行时赋值
        self.num_decoder_tokens = 0                                     # decoder中token数量，在运行时赋值
        self.max_encoder_seq_length = 0                                 # encoder中最大序列长度，在运行时赋值
        self.max_decoder_seq_length = 0                                 # dncoder中最大序列长度，在运行时赋值
        self.input_length = 0                                           # 输入序列长度，在运行时赋值



class MyModel(tf.keras.Model):
    def __init__(self, config):
        super(MyModel, self).__init__()
        self.config = config


    def createModel(self):
        # batch_size x 3782
        # encoder_inputs输入是 batch_size x 3782 tensor
        encoder_inputs = Input(shape=(None, self.config.num_encoder_tokens)) #(None, None, 3782)

        # 编码器的lstm返回最后一个隐藏层状态 return_state=True参数表示该函数将返回LSTM的输出状态，包括最终的隐藏状态和细胞状态，以便在模型中进行后续处理。
        encoder_lstm = LSTM((self.config.hidden_size), return_state=True)
 #返回一个三元组 (outputs, hidden_state, cell_state)。 (batch_size, sequence_length, hidden_size)
        # hidden_state： 是LSTM在最后一个时间步骤的隐藏状态，它是一个二维张量(batch_size, hidden_size)
        #               编码器，返回最后的输出，历史的state, 当前state
        #cell_state ：是LSTM在最后一个时间步骤的细胞状态，它也是一个二维张量 (batch_size, hidden_size)，

        encoder_outputs, state_h, state_c = encoder_lstm(encoder_inputs) #(None, 256)

        # 仅仅考虑state_h, state_c作为解码器的输出入
        encoder_states = [state_h, state_c]

        # 解码器，使用encoder_states作为初始state.  batch_size * 3863
        decoder_inputs = Input(shape=(None, self.config.num_decoder_tokens))

        # 编码器LSTM，获取全部的输出
        decoder_lstm = LSTM((self.config.hidden_size), return_sequences=True, return_state=True)

        # 编码器输出
#return_sequences=True 参数表示该函数将返回所有时间步骤的LSTM输出，而不仅仅是最后一个时间步骤的输出。
        decoder_outputs, _, _ = decoder_lstm(decoder_inputs, initial_state=encoder_states)

        # 预测下一个词的概率 3863 units
        decoder_dense = Dense(self.config.num_decoder_tokens, activation='softmax')

        decoder_outputs = decoder_dense(decoder_outputs)

        # 关联编码器解码器
        model = tf.keras.Model([encoder_inputs, decoder_inputs], decoder_outputs)
        return model
