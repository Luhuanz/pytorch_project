#!/usr/bin/python
# -*- coding: UTF-8 -*-
#Author bruce
import numpy as np
from tqdm import tqdm
import time
from datetime import timedelta

#该函数从一个文本文件中读取行，并将每一行分成输入和目标文本。它使用“＃”字符作为输入和目标文本之间的分隔符，并在目标文本的开头添加“＃”字符，
# 以作为起始序列。它还将输入和目标文本中出现的每个字符添加到对应的字符集合中。
def process_text(config):
    input_texts = [] # 用于存储输入文本的列表
    target_texts = [] # 用于存储目标文本的列表
    input_characters = set() # 用于存储输入文本中出现的字符的集合
    target_characters = set()# 用于存储目标文本中出现的字符的集合
    with open(config.train_path, 'r', encoding='utf-8') as f:
        lines = f.read().split('\n')# 读取文件，并将其分割为一行一行的文本
    print("处理原始数据：")
#具体来说，min(config.num_samples, len(lines) - 1) 将选择 config.num_samples 和列表长度减1中较小的那个数字。如果列表长度小于等于1，则切片将为空。
    for line in tqdm(lines[: min(config.num_samples, len(lines) - 1)]):  # 对于每一行文本
        input_text, target_text = line.split('#')# 将输入和目标文本分离，并使用'#'作为分隔符
        # 我们使用"\t"作为目标文本的"起始序列"字符，使用"\n"作为"结束序列"字符
        target_text = '#' + target_text + '\n'
        input_texts.append(input_text) # 将输入文本添加到input_texts列表中
        target_texts.append(target_text)# 将目标文本添加到target_texts列表中
        for char in input_text:
            if char not in input_characters:  # 如果这个字符还没有出现在input_characters集合中，那么就添加进去
                input_characters.add(char)
        for char in target_text:
            if char not in target_characters: # 如果这个字符还没有出现在target_characters集合中，那么就添加进去
                target_characters.add(char)

    input_characters = sorted(list(input_characters))
    target_characters = sorted(list(target_characters))
    return input_texts, target_texts, input_characters, target_characters

def bulid_token_index(input_texts, target_texts, input_characters, target_characters):
    input_characters = sorted(list(input_characters))# 将输入字符集合转换为排序列表
    target_characters = sorted(list(target_characters)) # 将目标字符集合转换为排序列表
    num_encoder_tokens = len(input_characters) # 输入字符的数量  3782
    num_decoder_tokens = len(target_characters) # 目标字符的数量 3863
    max_encoder_seq_length = max([len(txt) for txt in input_texts]) # 最长的输入序列长度 57
    max_decoder_seq_length = max([len(txt) for txt in target_texts]) # 最长的目标序列长度 59

    print('Number of samples:', len(input_texts))# 样本数量
    print('Number of unique input tokens:', num_encoder_tokens)# 输入字符的数量
    print('Number of unique output tokens:', num_decoder_tokens)# 目标字符的数量
    print('Max sequence length for inputs:', max_encoder_seq_length) # 最长的输入序列长度
    print('Max sequence length for outputs:', max_decoder_seq_length) # 最长的目标序列长度

    input_token_index = dict([(char, i) for i, char in enumerate(input_characters)]) # 将每个输入字符映射为一个整数索引
    target_token_index = dict([(char, i) for i, char in enumerate(target_characters)]) # 将每个目标字符映射为一个整数索引
    return num_encoder_tokens, num_decoder_tokens, max_encoder_seq_length, max_decoder_seq_length, input_token_index, target_token_index

def build_dataset(input_texts, target_texts, num_encoder_tokens, num_decoder_tokens, max_encoder_seq_length, max_decoder_seq_length, input_token_index, target_token_index):

    # 构建模型输入数据np.zeros(shape, dtype, order)
    encoder_input_data = np.zeros(
        (len(input_texts), max_encoder_seq_length, num_encoder_tokens),
        dtype='float32') # 10000 57 3782
    decoder_input_data = np.zeros(
        (len(input_texts), max_decoder_seq_length, num_decoder_tokens),
        dtype='float32')
    decoder_target_data = np.zeros(
        (len(input_texts), max_decoder_seq_length, num_decoder_tokens),
        dtype='float32')
#将输入序列和目标序列转换为模型训练所需的数据格式。
    for i, (input_text, target_text) in enumerate(zip(input_texts, target_texts)):
        for t, char in enumerate(input_text):
            # 3D vector only z-index has char its value equals 1.0
            encoder_input_data[i, t, input_token_index[char]] = 1.
        for t, char in enumerate(target_text):
            # decoder_target_data is ahead of decoder_input_data by one timestep
            decoder_input_data[i, t, target_token_index[char]] = 1.
            if t > 0:
                # decoder_target_data will be ahead by one timestep
                # and will not include the start character.
                # igone t=0 and start t=1, means
                decoder_target_data[i, t - 1, target_token_index[char]] = 1.

    return encoder_input_data, decoder_input_data, decoder_target_data

def get_time_dif(start_time):
    """获取已使用时间"""
    end_time = time.time()
    time_dif = end_time - start_time
    return timedelta(seconds=int(round(time_dif)))

